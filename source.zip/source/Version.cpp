#include "Version.hpp"
#include "TeamID.hpp"

/* Do not modify this file. It automatically compiles the current
 * date & time, so that you can verify you're using the right version
 * of your code in the simulator.
 */

char* PrintVersion() {
  return "Compiled: " __DATE__ " at " __TIME__;
}

#pragma once

/* Do not modify this file. It automatically compiles the current
 * date & time, so that you can verify you're using the right version
 * of your code in the simulator.
 */

extern "C" {
char* PrintVersion();
}
